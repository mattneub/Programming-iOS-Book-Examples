

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface MyLayer : CALayer 
@end
