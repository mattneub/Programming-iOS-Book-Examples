

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface CompassLayer : CALayer 
@end
