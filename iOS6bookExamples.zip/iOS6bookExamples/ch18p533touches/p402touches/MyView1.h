
#import <UIKit/UIKit.h>

@interface MyView1 : UIView

@end
