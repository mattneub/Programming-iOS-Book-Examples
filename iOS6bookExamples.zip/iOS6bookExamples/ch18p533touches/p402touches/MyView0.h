

#import <UIKit/UIKit.h>

@interface MyView0 : UIView

@end
