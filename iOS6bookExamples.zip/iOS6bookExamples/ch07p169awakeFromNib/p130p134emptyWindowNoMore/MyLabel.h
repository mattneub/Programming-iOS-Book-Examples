

#import <UIKit/UIKit.h>

@interface MyLabel : UILabel

@end
