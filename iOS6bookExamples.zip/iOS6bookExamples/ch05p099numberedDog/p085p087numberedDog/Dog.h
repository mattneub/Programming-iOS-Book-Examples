

#import <Foundation/Foundation.h>


@interface Dog : NSObject 

- (void) setNumber: (int) n;
- (int) number;

@end
