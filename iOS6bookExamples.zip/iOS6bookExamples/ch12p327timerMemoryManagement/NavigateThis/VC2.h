
#import <UIKit/UIKit.h>

@interface VC2 : UITableViewController

@end
