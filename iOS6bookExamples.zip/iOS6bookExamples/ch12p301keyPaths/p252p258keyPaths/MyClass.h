

#import <Foundation/Foundation.h>


@interface MyClass : NSObject 
@property (nonatomic, strong) NSMutableArray* theData;

@end
