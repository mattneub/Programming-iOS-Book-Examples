

#import <Foundation/Foundation.h>

@interface VertPanGestureRecognizer : UIPanGestureRecognizer
@end
