

#import <Foundation/Foundation.h>
#import "Dog.h"

@interface NoisyDog : Dog {
    
}

@end
