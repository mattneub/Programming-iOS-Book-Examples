

#import "FlipsideViewController.h"

@interface MainViewController : UIViewController 

- (IBAction)showInfo:(id)sender;

@end
