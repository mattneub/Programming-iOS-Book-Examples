

#import "MyClass.h"

@implementation MyClass
@end
