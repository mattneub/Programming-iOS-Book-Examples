
#import <UIKit/UIKit.h>

@interface MyView4 : UIView

@end
