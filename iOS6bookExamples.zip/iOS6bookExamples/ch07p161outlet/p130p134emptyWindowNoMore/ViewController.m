

#import "ViewController.h"

@implementation ViewController

- (IBAction)doButton:(id)sender {
    // just proving to myself that no constraints are magically added
    //[self.view layoutIfNeeded];
    //NSLog(@"%@", [self.view.subviews[0] constraints]);
    //NSLog(@"%@", [self.view constraints]);
}


@end
