

#import <Foundation/Foundation.h>


@interface Dog : NSObject
- (id) initWithNumber: (int) n;
- (int) number;
@end
