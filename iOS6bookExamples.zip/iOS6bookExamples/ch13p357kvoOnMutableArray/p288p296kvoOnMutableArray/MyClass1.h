

#import <Foundation/Foundation.h>


@interface MyClass1 : NSObject 

@property (nonatomic, strong, getter=theDataGetter) NSMutableArray* theData;

@end
