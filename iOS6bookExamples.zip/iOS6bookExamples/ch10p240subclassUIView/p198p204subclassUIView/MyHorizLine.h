

#import <UIKit/UIKit.h>


@interface MyHorizLine : UIView {
    
}

@end
