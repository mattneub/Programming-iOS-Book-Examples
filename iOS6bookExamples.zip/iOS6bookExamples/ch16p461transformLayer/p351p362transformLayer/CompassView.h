

#import <UIKit/UIKit.h>


@interface CompassView : UIView
@end
