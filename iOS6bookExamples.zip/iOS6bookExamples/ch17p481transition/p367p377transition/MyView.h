

#import <UIKit/UIKit.h>


@interface MyView : UIView

@property (nonatomic, assign) BOOL reverse;

@end
