

#import <Foundation/Foundation.h>

@interface MyClass : NSObject
- (void) setThing: (id) what;
@end
