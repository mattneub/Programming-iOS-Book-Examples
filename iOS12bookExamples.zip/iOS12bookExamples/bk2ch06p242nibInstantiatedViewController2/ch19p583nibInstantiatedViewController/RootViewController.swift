

import UIKit

class RootViewController : UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(self.view)
    }
    
}
