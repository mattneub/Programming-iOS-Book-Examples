

import UIKit

class Cell : UICollectionViewCell {
    @IBOutlet var lab : UILabel!
}
