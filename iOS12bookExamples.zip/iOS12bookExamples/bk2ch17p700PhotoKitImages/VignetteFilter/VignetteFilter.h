//
//  VignetteFilter.h
//  VignetteFilter
//
//  Created by Matt Neuburg on 1/29/16.
//  Copyright © 2016 Matt Neuburg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for VignetteFilter.
FOUNDATION_EXPORT double VignetteFilterVersionNumber;

//! Project version string for VignetteFilter.
FOUNDATION_EXPORT const unsigned char VignetteFilterVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VignetteFilter/PublicHeader.h>


