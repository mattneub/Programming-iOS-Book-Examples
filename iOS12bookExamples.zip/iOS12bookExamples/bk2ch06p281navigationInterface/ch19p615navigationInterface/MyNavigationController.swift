

import UIKit

class MyNavigationController: UINavigationController {

//    override var preferredStatusBarStyle : UIStatusBarStyle {
//        return .lightContent
//    }
    
//    override var childViewControllerForStatusBarStyle : UIViewController? {
//        return self.topViewController
//    }

}
