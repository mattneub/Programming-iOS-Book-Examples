
import UIKit

class ThirdViewController: SecondViewController {

    @IBAction override func doDismiss(_ sender: Any?) {
        super.doDismiss(sender)
    }

}
