

import UIKit

// not used

/*
class MyImagePickerController: UIImagePickerController {
    
    override var supportedInterfaceOrientations : UIInterfaceOrientationMask {
        return self.presentingViewController!.supportedInterfaceOrientations
    }

}
*/
