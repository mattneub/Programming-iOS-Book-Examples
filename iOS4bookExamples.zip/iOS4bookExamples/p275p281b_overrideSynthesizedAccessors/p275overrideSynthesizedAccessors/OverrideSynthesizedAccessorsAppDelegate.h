

#import <UIKit/UIKit.h>

@interface OverrideSynthesizedAccessorsAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
