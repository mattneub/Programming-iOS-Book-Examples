

#import <UIKit/UIKit.h>

@interface FunctionPointerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
