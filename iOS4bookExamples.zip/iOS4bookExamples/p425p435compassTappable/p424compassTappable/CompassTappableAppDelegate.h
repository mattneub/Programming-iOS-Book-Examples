

#import <UIKit/UIKit.h>

@interface CompassTappableAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
