

#import <UIKit/UIKit.h>

@interface ContentModeAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
