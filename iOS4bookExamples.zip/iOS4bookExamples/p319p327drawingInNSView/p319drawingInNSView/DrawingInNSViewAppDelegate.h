
#import <UIKit/UIKit.h>

@interface DrawingInNSViewAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
