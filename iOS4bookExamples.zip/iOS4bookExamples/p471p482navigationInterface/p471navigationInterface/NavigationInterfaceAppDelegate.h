
#import <UIKit/UIKit.h>

@interface NavigationInterfaceAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
