
#import "LandscapeViewController.h"


@implementation LandscapeViewController



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)io
{
    // Return YES for supported orientations
    return UIInterfaceOrientationIsLandscape(io);
}

@end
