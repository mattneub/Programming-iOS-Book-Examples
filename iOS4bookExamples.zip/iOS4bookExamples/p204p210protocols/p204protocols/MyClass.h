

#import <Foundation/Foundation.h>

// @interface MyClass : NSObject <NSCopying> {
// uncomment the previous line, and comment out the next one, to get a different compiler warning
@interface MyClass : NSObject {
    
}

@end
