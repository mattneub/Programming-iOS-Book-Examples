
#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController {
    
}
@property (nonatomic, retain) NSData* myBigData;

@end
