

#import <Foundation/Foundation.h>


@interface MyLabel : UILabel {
    
}

@end
