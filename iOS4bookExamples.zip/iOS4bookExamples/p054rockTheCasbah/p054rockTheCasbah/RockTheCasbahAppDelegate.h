

#import <UIKit/UIKit.h>

@interface RockTheCasbahAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
