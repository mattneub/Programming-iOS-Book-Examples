

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController {
    
}
@property (nonatomic, retain) NSArray* states;
@property (nonatomic, retain) NSArray* filteredStates;

@end
