

#import <UIKit/UIKit.h>

@interface NumberedDogAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
