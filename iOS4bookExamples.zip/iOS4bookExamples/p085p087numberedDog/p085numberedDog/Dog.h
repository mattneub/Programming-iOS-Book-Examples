

#import <Foundation/Foundation.h>


@interface Dog : NSObject {
    int number;
}
- (void) setNumber: (int) n;
- (int) number;

@end
