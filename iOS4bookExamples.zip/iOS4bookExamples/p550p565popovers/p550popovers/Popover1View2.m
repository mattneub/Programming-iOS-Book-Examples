
#import "Popover1View2.h"


@implementation Popover1View2

- (void) viewDidLoad {
    self.view.backgroundColor = [UIColor redColor];
    self.contentSizeForViewInPopover = CGSizeMake(400,400);
}

@end
