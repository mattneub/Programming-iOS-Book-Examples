

#import <UIKit/UIKit.h>

@interface ViewAnimationOldAppDelegate : NSObject <UIApplicationDelegate> {

    UIView *v;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIView *v;

@end
