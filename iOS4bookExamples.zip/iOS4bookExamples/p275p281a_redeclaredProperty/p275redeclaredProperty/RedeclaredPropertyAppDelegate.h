

#import <UIKit/UIKit.h>

@interface RedeclaredPropertyAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
