

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface CompassLayer : CALayer {
    CALayer* rotationLayer;
}

@end
