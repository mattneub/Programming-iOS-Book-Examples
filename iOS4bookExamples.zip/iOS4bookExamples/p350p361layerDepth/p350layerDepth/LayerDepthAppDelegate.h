

#import <UIKit/UIKit.h>

@interface LayerDepthAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
