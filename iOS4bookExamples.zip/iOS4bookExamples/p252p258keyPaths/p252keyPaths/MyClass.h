

#import <Foundation/Foundation.h>


@interface MyClass : NSObject {
    NSMutableArray* theData;
}
@property (nonatomic, assign) NSMutableArray* theData;

@end
