

#import <UIKit/UIKit.h>

@interface KeyPathsAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
