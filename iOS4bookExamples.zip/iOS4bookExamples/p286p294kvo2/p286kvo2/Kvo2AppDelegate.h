
#import <UIKit/UIKit.h>

@interface Kvo2AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
