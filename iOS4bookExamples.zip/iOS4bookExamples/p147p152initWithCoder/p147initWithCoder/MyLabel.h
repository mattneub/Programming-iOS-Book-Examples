

#import <Foundation/Foundation.h>


@interface MyLabel : UILabel {
    int num;
}

@end
