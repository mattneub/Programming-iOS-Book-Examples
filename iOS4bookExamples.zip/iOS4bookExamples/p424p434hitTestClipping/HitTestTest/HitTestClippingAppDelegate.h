

#import <UIKit/UIKit.h>

@interface HitTestClippingAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
