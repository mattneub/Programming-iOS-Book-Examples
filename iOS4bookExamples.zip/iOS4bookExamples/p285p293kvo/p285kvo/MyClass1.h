

#import <Foundation/Foundation.h>


@interface MyClass1 : NSObject {
    NSString* value;
}
@property (nonatomic, copy) NSString* value;
@end

