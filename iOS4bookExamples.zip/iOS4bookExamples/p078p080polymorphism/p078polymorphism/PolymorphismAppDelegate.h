

#import <UIKit/UIKit.h>

@interface PolymorphismAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
