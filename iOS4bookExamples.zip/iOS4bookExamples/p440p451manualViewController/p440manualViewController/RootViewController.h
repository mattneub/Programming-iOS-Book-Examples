

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {
    
}
@property (nonatomic, assign) IBOutlet UILabel* theLabel;

@end
