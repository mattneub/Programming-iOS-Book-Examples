

#import <Foundation/Foundation.h>


@interface Dog : NSObject {
    int number;
}
@property (nonatomic) int number;
@end
