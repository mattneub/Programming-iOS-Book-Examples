

#import <UIKit/UIKit.h>

@interface GroupedAnimationAppDelegate : NSObject <UIApplicationDelegate> {

    UIView *view;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIView *view;

@end
