
#import <UIKit/UIKit.h>

@interface NibInstantiatedViewControllerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
