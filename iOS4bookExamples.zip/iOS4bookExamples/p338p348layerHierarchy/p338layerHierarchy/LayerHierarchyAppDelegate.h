

#import <UIKit/UIKit.h>

@interface LayerHierarchyAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
