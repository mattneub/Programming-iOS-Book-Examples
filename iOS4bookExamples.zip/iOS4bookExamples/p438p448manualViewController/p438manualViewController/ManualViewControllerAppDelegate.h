

#import <UIKit/UIKit.h>
@class RootViewController;
@interface ManualViewControllerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) RootViewController* rvc;

@end
