

#import <Foundation/Foundation.h>


@interface MyTextField : UITextField {
    
}
@property (nonatomic, assign) IBOutlet UITextField* nextField;

@end
