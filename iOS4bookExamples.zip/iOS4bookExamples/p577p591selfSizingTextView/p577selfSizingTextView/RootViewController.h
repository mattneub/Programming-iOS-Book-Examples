

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController {
    
    UITextView *tv;
}
@property (nonatomic, retain) IBOutlet UITextView *tv;

@end
