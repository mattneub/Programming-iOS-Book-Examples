

#import <UIKit/UIKit.h>


@interface WebViewController : UIViewController <UIWebViewDelegate> {
    
}
@property (nonatomic, retain) UIActivityIndicatorView* activity;

@end
