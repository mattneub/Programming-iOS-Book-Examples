
#import <Foundation/Foundation.h>

@interface NSString (MyStringCategories) 
- (NSString*) basePictureName;
@end

@end
