

#import <UIKit/UIKit.h>

@interface SubclassUIView : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
