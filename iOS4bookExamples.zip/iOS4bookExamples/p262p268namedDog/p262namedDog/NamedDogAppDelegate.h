

#import <UIKit/UIKit.h>

@interface NamedDogAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
