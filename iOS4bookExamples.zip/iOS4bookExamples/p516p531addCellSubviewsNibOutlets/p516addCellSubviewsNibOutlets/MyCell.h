
#import <UIKit/UIKit.h>


@interface MyCell : UITableViewCell {
    
}
@property (nonatomic, assign) IBOutlet UILabel* theLabel; 
@property (nonatomic, assign) IBOutlet UIImageView* theImageView;

@end
