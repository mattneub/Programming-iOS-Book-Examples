

#import "MyCell.h"


@implementation MyCell
@synthesize theLabel, theImageView;


@end
