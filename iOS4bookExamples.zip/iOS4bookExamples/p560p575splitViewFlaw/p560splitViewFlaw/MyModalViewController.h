
#import <UIKit/UIKit.h>


@interface MyModalViewController : UIViewController {
    
}

@end
