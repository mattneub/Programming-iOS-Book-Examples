

#import <Foundation/Foundation.h>


@interface Dog : NSObject {
    int number;
}
- (id) initWithNumber: (int) n;
- (int) number;
@end
