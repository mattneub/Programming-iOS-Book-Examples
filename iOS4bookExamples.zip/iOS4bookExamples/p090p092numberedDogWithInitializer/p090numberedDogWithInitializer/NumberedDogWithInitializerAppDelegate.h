

#import <UIKit/UIKit.h>

@interface NumberedDogWithInitializerAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
