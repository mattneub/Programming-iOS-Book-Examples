

#import <UIKit/UIKit.h>


@interface MyView : UIView {
    BOOL reverse;
}

@property (nonatomic, assign) BOOL reverse;

@end
