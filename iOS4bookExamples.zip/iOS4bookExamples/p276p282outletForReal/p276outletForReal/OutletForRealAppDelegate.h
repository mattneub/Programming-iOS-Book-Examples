

#import <UIKit/UIKit.h>

@interface OutletForRealAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
