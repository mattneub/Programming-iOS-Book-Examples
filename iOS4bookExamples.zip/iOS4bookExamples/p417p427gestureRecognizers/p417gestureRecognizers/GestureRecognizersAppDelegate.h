
#import <UIKit/UIKit.h>

@interface GestureRecognizersAppDelegate : NSObject <UIApplicationDelegate> {

    UIView *view;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UIView *view;

@end
