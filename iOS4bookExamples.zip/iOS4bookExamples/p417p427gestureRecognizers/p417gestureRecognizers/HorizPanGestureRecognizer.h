

#import <Foundation/Foundation.h>

@interface HorizPanGestureRecognizer : UIPanGestureRecognizer {
    CGPoint origLoc;
}

@end
