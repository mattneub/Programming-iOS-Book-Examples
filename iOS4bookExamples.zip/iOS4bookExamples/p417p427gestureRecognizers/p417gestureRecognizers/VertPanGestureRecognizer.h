

#import <Foundation/Foundation.h>

@interface VertPanGestureRecognizer : UIPanGestureRecognizer {
    CGPoint origLoc;
}

@end
