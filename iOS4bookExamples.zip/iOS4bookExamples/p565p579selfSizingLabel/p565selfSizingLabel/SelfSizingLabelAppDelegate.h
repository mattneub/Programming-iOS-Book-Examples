
#import <UIKit/UIKit.h>

@interface SelfSizingLabelAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UILabel *theLabel;

@end
