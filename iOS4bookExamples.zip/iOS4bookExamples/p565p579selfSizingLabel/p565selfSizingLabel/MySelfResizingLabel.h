
#import <Foundation/Foundation.h>


@interface MySelfResizingLabel : UILabel {
    
}

@end
