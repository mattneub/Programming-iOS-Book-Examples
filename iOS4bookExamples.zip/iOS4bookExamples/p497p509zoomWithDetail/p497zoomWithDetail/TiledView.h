

#import <UIKit/UIKit.h>


@interface TiledView : UIView {
    
}

@end
