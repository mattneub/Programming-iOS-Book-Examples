

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {

}
@property (nonatomic, retain) NSMutableArray* sectionNames;
@property (nonatomic, retain) NSMutableArray* sectionData;


@end
