
#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController {
    
}
@property (nonatomic, retain) UIView* blackRect;

@end
