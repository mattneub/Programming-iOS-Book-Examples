
#import <UIKit/UIKit.h>

@interface FoundationClassesAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
