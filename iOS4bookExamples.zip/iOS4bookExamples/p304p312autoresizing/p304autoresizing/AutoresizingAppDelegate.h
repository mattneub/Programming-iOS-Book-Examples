

#import <UIKit/UIKit.h>

@interface AutoresizingAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
