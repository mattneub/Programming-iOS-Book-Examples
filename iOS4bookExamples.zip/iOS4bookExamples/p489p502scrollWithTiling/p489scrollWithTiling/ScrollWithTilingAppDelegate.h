

#import <UIKit/UIKit.h>

@class RootViewController;

@interface ScrollWithTilingAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet RootViewController *viewController;

@end
