

#import <UIKit/UIKit.h>

#define TILESIZE 256

@interface TiledView : UIView {
    

}

@end
