
#import <UIKit/UIKit.h>


@interface MyCell : UITableViewCell {

}

@property (nonatomic, assign) IBOutlet UITextField* textField;

@end
