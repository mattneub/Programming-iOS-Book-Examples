

#import "MyClass.h"


@implementation MyClass
@synthesize theLabel;


@end
