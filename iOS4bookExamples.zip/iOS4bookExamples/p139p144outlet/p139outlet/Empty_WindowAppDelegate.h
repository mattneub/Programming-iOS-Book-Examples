

#import <UIKit/UIKit.h>

@interface Empty_WindowAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
