

#import <UIKit/UIKit.h>


@interface MyCell : UITableViewCell {
    
}

@end
