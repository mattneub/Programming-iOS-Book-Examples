

#import <UIKit/UIKit.h>

@interface NilTestingAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
