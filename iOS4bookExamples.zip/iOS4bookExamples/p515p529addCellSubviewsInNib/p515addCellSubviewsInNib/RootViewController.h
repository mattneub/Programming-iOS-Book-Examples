

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {

}
@property (nonatomic, assign) IBOutlet UITableViewCell* tvc;


@end
