

#import <UIKit/UIKit.h>

@interface PrivateMethodAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
