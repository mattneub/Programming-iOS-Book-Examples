
#import <Foundation/Foundation.h>


@interface MyClass : NSObject {
    
}

- (NSString*) publicMethod;

@end
