

// function declarations go here

int square(int i);