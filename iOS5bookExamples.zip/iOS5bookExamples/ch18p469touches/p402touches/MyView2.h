

#import <UIKit/UIKit.h>

@interface MyView2 : UIView

@end
