

#import <Foundation/Foundation.h>

@interface HorizPanGestureRecognizer : UIPanGestureRecognizer 
@end
