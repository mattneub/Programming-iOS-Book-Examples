

#import <Foundation/Foundation.h>

@interface MyClass : UIViewController
@property (nonatomic, strong) IBOutlet UILabel* theLabel;
@end
