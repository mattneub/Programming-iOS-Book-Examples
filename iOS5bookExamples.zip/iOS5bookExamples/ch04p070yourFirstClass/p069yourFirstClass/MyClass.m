

#import "MyClass.h"


@implementation MyClass

- (NSString*) sayGoodnightGracie {
    return @"Good night, Gracie!";
}

@end
