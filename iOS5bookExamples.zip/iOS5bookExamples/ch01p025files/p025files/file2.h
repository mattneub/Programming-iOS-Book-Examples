
// function declarations go here

void doYourThing(void);