
#import <UIKit/UIKit.h>


@interface View2Controller : UIViewController {
    
}

@end
