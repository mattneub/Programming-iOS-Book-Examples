

#import <UIKit/UIKit.h>

@interface PanelViewController : UIViewController

@end
