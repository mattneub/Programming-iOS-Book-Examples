

#import "MyClass.h"

@implementation MyClass {
}

- (void) dealloc {
    NSLog(@"dealloc");
}

@end
