

#import <Foundation/Foundation.h>


@interface Dog : NSObject 
- (id) initWithName: (NSString*) s;
- (NSString*) name;
// - (void) setName: (NSString*) s;
@end
