

#import <Foundation/Foundation.h>


@interface MyBoundedLabel : UILabel {
    
}

@end
