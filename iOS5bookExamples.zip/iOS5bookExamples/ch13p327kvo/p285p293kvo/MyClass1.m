

#import "MyClass1.h"

@implementation MyClass1
@synthesize value;
@end
