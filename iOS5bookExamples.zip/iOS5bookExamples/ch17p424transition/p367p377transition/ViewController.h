

#import <UIKit/UIKit.h>
@class MyView;

@interface ViewController : UIViewController
@property (nonatomic, retain) IBOutlet UIImageView *iv;
@property (nonatomic, retain) IBOutlet UIButton *b;
@property (nonatomic, retain) IBOutlet MyView *v;
@property (nonatomic, retain) IBOutlet UIView *v2;

@end
