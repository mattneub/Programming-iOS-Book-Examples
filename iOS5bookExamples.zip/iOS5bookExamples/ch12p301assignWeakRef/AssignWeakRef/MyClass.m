
#import "MyClass.h"

@implementation MyClass
@synthesize delegate;

@end
