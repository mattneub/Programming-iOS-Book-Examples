

#import <Foundation/Foundation.h>

@interface SegueNoAnimation : UIStoryboardSegue

@end
