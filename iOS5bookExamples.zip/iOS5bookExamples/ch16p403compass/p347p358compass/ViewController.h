

#import <UIKit/UIKit.h>
@class CompassView;

@interface ViewController : UIViewController
@property (nonatomic, strong) IBOutlet CompassView* compass;
@end
