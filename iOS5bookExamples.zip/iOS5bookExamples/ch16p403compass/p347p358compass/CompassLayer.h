

#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

@interface CompassLayer : CALayer {
}
@property (nonatomic, strong) CALayer* arrow;

@end
