

#import <Foundation/Foundation.h>


@interface Dog : NSObject 
@property (nonatomic) int number;
@end
