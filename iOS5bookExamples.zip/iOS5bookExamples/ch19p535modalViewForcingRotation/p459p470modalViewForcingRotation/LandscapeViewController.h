

#import <UIKit/UIKit.h>


@interface LandscapeViewController : UIViewController {
    
}

@end
