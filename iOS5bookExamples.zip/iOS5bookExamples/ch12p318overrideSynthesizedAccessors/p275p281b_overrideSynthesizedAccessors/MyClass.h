

#import <Foundation/Foundation.h>


@interface MyClass : NSObject {
    
}

// as far as the world knows, we have a property myIvar
@property (nonatomic, strong) NSNumber* myIvar;

@end
