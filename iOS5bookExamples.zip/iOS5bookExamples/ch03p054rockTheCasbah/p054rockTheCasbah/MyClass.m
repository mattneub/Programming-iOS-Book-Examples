

#import "MyClass.h"

@implementation MyClass

- (void) rockTheCasbah {
    
}

@end
